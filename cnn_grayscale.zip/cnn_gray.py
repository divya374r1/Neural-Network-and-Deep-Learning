import torch
import torch.nn as nn
import cv2
import matplotlib.pyplot as plt
import numpy as np

# Load image
img = cv2.imread("image.jpeg")
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

# Convert to tensor
img_tensor = torch.tensor(img, dtype=torch.float32).permute(2,0,1).unsqueeze(0) / 255.0

# CNN model
class GrayCNN(nn.Module):
    def __init__(self):
        super(GrayCNN, self).__init__()
        self.conv = nn.Conv2d(3, 1, kernel_size=1, bias=False)

        # grayscale weights
        weights = torch.tensor([0.299, 0.587, 0.114]).view(1,3,1,1)
        self.conv.weight = nn.Parameter(weights)

    def forward(self, x):
        return self.conv(x)

model = GrayCNN()

# Forward pass
gray = model(img_tensor)
gray_img = gray.squeeze().detach().numpy()

# SAVE grayscale image
gray_save = (gray_img * 255).astype("uint8")
cv2.imwrite("gray_output.jpg", gray_save)

# Display
plt.figure(figsize=(10,5))
plt.subplot(1,2,1)
plt.title("Original Image")
plt.imshow(img)
plt.axis("off")

plt.subplot(1,2,2)
plt.title("Grayscale using CNN")
plt.imshow(gray_img, cmap="gray")
plt.axis("off")

plt.show()
